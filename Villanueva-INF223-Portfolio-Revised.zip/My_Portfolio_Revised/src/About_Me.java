
public class About_Me {

	String bday = "September 16, 2003";
	String homeTown = "Malabon City";
	String live = "Quezon City";
	String nationality = "Filipino";
	String prefLanguage = "English and Tagalog";
	String religion = "Roman Catholic";
	
}
