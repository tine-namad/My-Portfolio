import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class design_StrsNWkns extends JFrame {

	private JPanel contentPane;
	//instantiation
	Strs_N_Wkns ins = new Strs_N_Wkns();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					design_StrsNWkns frame = new design_StrsNWkns();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public design_StrsNWkns() {
		setResizable(false);
		setTitle("My Portfolio - Strengths and Weaknesses");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 896, 512);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btn_return = new JButton("Return");
		btn_return.setBackground(new Color(0, 0, 0));
		btn_return.setForeground(new Color(255, 255, 255));
		btn_return.setFont(new Font("Century Gothic", Font.BOLD, 15));
		btn_return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_HomePage page = new design_HomePage();
				page.show();
				dispose();
			}
		});
		btn_return.setBounds(719, 421, 108, 28);
		btn_return.setFocusable(false);
		btn_return.setBorderPainted(false);
		contentPane.add(btn_return);
		
		JLabel lbl_comms = new JLabel(ins.comms);
		lbl_comms.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_comms.setBounds(96, 169, 142, 24);
		contentPane.add(lbl_comms);
		
		JLabel lbl_details = new JLabel(ins.detail);
		lbl_details.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_details.setBounds(96, 203, 185, 24);
		contentPane.add(lbl_details);
		
		JLabel lbl_working = new JLabel(ins.work);
		lbl_working.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_working.setBounds(96, 234, 142, 24);
		contentPane.add(lbl_working);
		
		JLabel lbl_multitask = new JLabel(ins.multitask);
		lbl_multitask.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_multitask.setBounds(96, 265, 142, 24);
		contentPane.add(lbl_multitask);
		
		JLabel lbl_creative = new JLabel(ins.creative);
		lbl_creative.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_creative.setBounds(96, 299, 142, 24);
		contentPane.add(lbl_creative);
		
		JLabel lbl_resilient = new JLabel(ins.resilient);
		lbl_resilient.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_resilient.setBounds(96, 333, 142, 24);
		contentPane.add(lbl_resilient);
		
		JLabel lbl_charisma = new JLabel(ins.charisma);
		lbl_charisma.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_charisma.setBounds(96, 365, 142, 24);
		contentPane.add(lbl_charisma);
		
		JLabel lbl_overthink = new JLabel(ins.overthink);
		lbl_overthink.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_overthink.setBounds(638, 169, 142, 24);
		contentPane.add(lbl_overthink);
		
		JLabel lbl_negativity = new JLabel(ins.negative);
		lbl_negativity.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_negativity.setBounds(638, 203, 142, 24);
		contentPane.add(lbl_negativity);
		
		JLabel lbl_procastinate = new JLabel(ins.procastinate);
		lbl_procastinate.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_procastinate.setBounds(638, 234, 142, 24);
		contentPane.add(lbl_procastinate);
		
		JLabel lbl_lowSelf = new JLabel(ins.lowSelf);
		lbl_lowSelf.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_lowSelf.setBounds(638, 268, 142, 24);
		contentPane.add(lbl_lowSelf);
		
		JLabel lbl_slowLearn = new JLabel(ins.slowLearn);
		lbl_slowLearn.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_slowLearn.setBounds(638, 299, 142, 24);
		contentPane.add(lbl_slowLearn);
		
		JLabel lbl_span = new JLabel(ins.span);
		lbl_span.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_span.setBounds(638, 333, 142, 24);
		contentPane.add(lbl_span);
		
		JLabel lbl_publicSpeak = new JLabel(ins.speak);
		lbl_publicSpeak.setFont(new Font("Century Gothic", Font.BOLD, 15));
		lbl_publicSpeak.setBounds(638, 365, 142, 24);
		contentPane.add(lbl_publicSpeak);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(design_StrsNWkns.class.getResource("/images/SnW.png")));
		lblNewLabel.setBounds(0, 0, 882, 475);
		contentPane.add(lblNewLabel);
	}

}
