import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class design_ContactInfo extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					design_ContactInfo frame = new design_ContactInfo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public design_ContactInfo() {
		setTitle("My Portfolio - Contact Info");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1061, 671);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btn_return = new JButton("Return");
		btn_return.setBackground(new Color(0, 0, 0));
		btn_return.setForeground(new Color(255, 255, 255));
		btn_return.setFont(new Font("Century Gothic", Font.BOLD, 20));
		btn_return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				design_HomePage page = new design_HomePage();
				page.show();
				dispose();
			}
		});
		btn_return.setBounds(885, 544, 108, 28);
		btn_return.setFocusable(false);
		btn_return.setBorderPainted(false);
		contentPane.add(btn_return);
		
		JLabel label = new JLabel("New label");
		label.setIcon(new ImageIcon(design_ContactInfo.class.getResource("/images/ContactInfo.png")));
		label.setBounds(0, 0, 1047, 634);
		contentPane.add(label);
	}

}
